#!/bin/bash

# I'm not sure why but this script fails to find 'npm' whenever it's run from inside VSCode.

npm run build

